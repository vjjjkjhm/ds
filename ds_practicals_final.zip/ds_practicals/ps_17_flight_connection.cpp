
#include<iostream>
#include<string>
using namespace std;

#define MAX 100

string city[MAX];
int g[MAX][MAX]={0};
int visited[MAX]={0};
int n;

void read()
{
    cout << "Enter number of cities: ";
    cin >> n;

    if(n<=0 || n>MAX)
    {
        cout << "Invalid number of cities";
        n=0;
        return;
    }

    for(int i=0; i<n; i++)
    {
        cout << "Enter city name: ";
        cin >> city[i];
    }

    for(int i=0; i<n; i++)
    {
        for(int j=i+1; j<n; j++)
        {
            char ch;

            cout << "Flight between "
                 << city[i] << " and "
                 << city[j] << " (Y/N): ";

            cin >> ch;

            if(ch=='Y' || ch=='y')
            {
                int time;

                cout << "Enter travel time: ";
                cin >> time;

                if(time<=0)
                {
                    cout << "Invalid travel time";
                    g[i][j]=g[j][i]=0;
                }
                else
                {
                    g[i][j]=time;
                    g[j][i]=time;
                }
            }
        }
    }
}

void display()
{
    cout << "\nAdjacency Matrix:\n\t";

    for(int i=0; i<n; i++)
        cout << city[i] << "\t";

    for(int i=0; i<n; i++)
    {
        cout << "\n" << city[i] << "\t";

        for(int j=0; j<n; j++)
            cout << g[i][j] << "\t";
    }

    cout << endl;
}

void DFS(int v)
{
    visited[v]=1;

    for(int i=0; i<n; i++)
    {
        if(g[v][i]!=0 && visited[i]==0)
        {
            DFS(i);
        }
    }
}

void check_connected()
{
    if(n==0)
        return;

    for(int i=0; i<n; i++)
        visited[i]=0;

    DFS(0);

    int connected=1;

    for(int i=0; i<n; i++)
    {
        if(visited[i]==0)
        {
            connected=0;
            break;
        }
    }

    if(connected==1)
        cout << "Graph is connected";
    else
        cout << "Graph is not connected";

    cout << endl;
}

int main()
{
    read();

    if(n==0)
        return 0;

    display();

    check_connected();

    return 0;
}

