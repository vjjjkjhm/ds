#include<iostream>
using namespace std;
class node{
	public:
	int data;
	node*next;
	
	
		node(int val){
			data=val;
			next=NULL;
			
		}
};
class stack{
	node *top;
	public:
		stack(){
			top=NULL;
		}
	void push(){
		int n;
		cout<<"enter element:"<<endl;
		cin>>n;
		node *newnode=new node(n);
		newnode->next=top;
		top=newnode;
		cout<<"element inserted successfully:"<<endl;
	}
	void pop(){
		if(top==NULL){
			cout<<"stack underflow"<<endl;
			return;
		}
		node *temp=top;
		cout<<"deleted element:"<<temp->data<<endl;
		top=top->next;
		delete temp;
	}
	int peek(){
		if(top==NULL){
			cout<<"stack underflow"<<endl;
			return -1;
		}
		return top->data;
	}
	void display(){
		if(top==NULL){
			cout<<"stack is empty"<<endl;
			return;
		}
		node *temp=top;
		cout<<"stack elements:"<<endl;
		while(temp!=NULL){
			cout<<temp->data<<"\t";
			temp=temp->next;
		}
	}
	~stack(){
		node *temp;
		while(top!=NULL){
			temp=top;
			top=top->next;
			delete temp;
		}
	}
};
int main(){
	stack s;
	int choice;
	do{
		
		cout<<"1.push"<<endl;
		cout<<"2.pop"<<endl;
		cout<<"3.peek"<<endl;
		cout<<"4.display"<<endl;
		cout<<"5.exit"<<endl;
		cout<<"enter choice:"<<endl;
		cin>>choice;
		switch(choice){
			
			case 1:
				s.push();
				break;
			case 2:
				s.pop();
				break;
			case 3:
				cout<<"top element:"<<s.peek()<<endl;
				break;
			case 4:
				s.display();
				break;
			case 5:
				cout<<"program terminated"<<endl;
				break;
			default:
				cout<<"invalid choice";
		}
	}while(choice!=5);
	
	return 0;
}
