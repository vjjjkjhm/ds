
#include<iostream>
using namespace std;

void selection_sort(int salary[], int n)
{
    for(int i=0; i<n-1; i++)
    {
        int min=i;

        for(int j=i+1; j<n; j++)
        {
            if(salary[j]<salary[min])
                min=j;
        }

        int temp=salary[i];
        salary[i]=salary[min];
        salary[min]=temp;
    }

    cout << "Salary sorted successfully" << endl;
}

void display(int salary[], int n)
{
    for(int i=0; i<n; i++)
        cout << salary[i] << "\t";

    cout << endl;
}

void top_five(int salary[], int n)
{
    int count=0;

    cout << "Top five highest salaries:" << endl;

    for(int i=n-1; i>=0 && count<5; i--)
    {
        cout << salary[i] << endl;
        count++;
    }
}

int main()
{
    int salary[100], n, choice;
    bool sorted=false;

    cout << "Enter number of employees: ";
    cin >> n;

    if(n<=0 || n>100)
    {
        cout << "Invalid number of employees";
        return 0;
    }

    for(int i=0; i<n; i++)
    {
        cout << "Enter salary of employee " << i+1 << ": ";
        cin >> salary[i];
    }

    do
    {
        cout << "\n1.Selection Sort";
        cout << "\n2.Display";
        cout << "\n3.Top Five Salaries";
        cout << "\n4.Exit";

        cout << "\nEnter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                selection_sort(salary,n);
                sorted=true;
                break;

            case 2:
                display(salary,n);
                break;

            case 3:
                if(sorted)
                    top_five(salary,n);
                else
                    cout << "Perform sorting first" << endl;
                break;

            case 4:
                cout << "Program terminated";
                break;

            default:
                cout << "Invalid choice";
        }

    }while(choice!=4);

    return 0;
}

