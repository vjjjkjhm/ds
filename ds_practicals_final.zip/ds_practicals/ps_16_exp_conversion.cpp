
#include<iostream>
#include<string>
using namespace std;

class node{
    public:
    char data;
    node *left,*right;

    node(char val){
        data=val;
        left=NULL;
        right=NULL;
    }
};

bool isoperator(char ch){
    if(ch=='+' || ch=='-' || ch=='*' || ch=='/' || ch=='^'){
        return true;
    }
    return false;
}

node* createtree(string prefix,int &i){

    if(i<0){
        return NULL;
    }

    node *newnode=new node(prefix[i]);
    i--;

    if(isoperator(newnode->data)){
        newnode->right=createtree(prefix,i);
        newnode->left=createtree(prefix,i);
    }

    return newnode;
}

void postorder(node *root){

    if(root==NULL){
        return;
    }

    postorder(root->left);
    postorder(root->right);
    cout<<root->data;
}

void deletetree(node *root){

    if(root==NULL){
        return;
    }

    deletetree(root->left);
    deletetree(root->right);
    delete root;
}

int main(){

    string prefix;
    int i;

    cout<<"Enter prefix expression:"<<endl;
    cin>>prefix;

    i=prefix.length()-1;

    node *root=createtree(prefix,i);

    cout<<"Postfix expression:"<<endl;
    postorder(root);

    cout<<endl;

    deletetree(root);
    root=NULL;

    cout<<"Tree deleted successfully"<<endl;

    return 0;
}

