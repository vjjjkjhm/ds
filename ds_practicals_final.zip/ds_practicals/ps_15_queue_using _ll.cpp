
#include<iostream>
using namespace std;

class node
{
public:
    int data;
    node *next;

    node(int val)
    {
        data=val;
        next=NULL;
    }
};

class queue
{
    node *front, *rear;

public:

    queue()
    {
        front=rear=NULL;
    }

    void enqueue()
    {
        int n;

        cout << "Enter element: ";
        cin >> n;

        node *newnode=new node(n);

        if(front==NULL)
        {
            front=rear=newnode;
        }
        else
        {
            rear->next=newnode;
            rear=newnode;
        }

        cout << "Element inserted successfully" << endl;
    }

    void dequeue()
    {
        if(front==NULL)
        {
            cout << "Queue underflow" << endl;
            return;
        }

        node *temp=front;

        cout << "Deleted element: " << temp->data << endl;

        front=front->next;

        if(front==NULL)
            rear=NULL;

        delete temp;
    }

    void traversal()
    {
        if(front==NULL)
        {
            cout << "Queue is empty" << endl;
            return;
        }

        node *temp=front;

        cout << "Queue elements: ";

        while(temp!=NULL)
        {
            cout << temp->data << "\t";
            temp=temp->next;
        }

        cout << endl;
    }

    ~queue()
    {
        node *temp;

        while(front!=NULL)
        {
            temp=front;
            front=front->next;
            delete temp;
        }

        rear=NULL;
    }
};

int main()
{
    queue q;
    int choice;

    do
    {
        cout << "\n1.Enqueue";
        cout << "\n2.Dequeue";
        cout << "\n3.Traversal";
        cout << "\n4.Exit";

        cout << "\nEnter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                q.enqueue();
                break;

            case 2:
                q.dequeue();
                break;

            case 3:
                q.traversal();
                break;

            case 4:
                cout << "Program terminated";
                break;

            default:
                cout << "Invalid choice";
        }

    }while(choice!=4);

    return 0;
}

