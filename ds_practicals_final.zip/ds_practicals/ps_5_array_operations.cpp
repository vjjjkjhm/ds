
#include<iostream>
using namespace std;

void display(int arr[], int n)
{
    for(int i=0; i<n; i++)
        cout << arr[i] << " ";

    cout << endl;
}

void insert(int arr[], int &n)
{
    int pos, value;

    if(n >= 100)
    {
        cout << "Array is full" << endl;
        return;
    }

    cout << "Enter index to insert: ";
    cin >> pos;

    if(pos < 0 || pos > n)
    {
        cout << "Invalid position" << endl;
        return;
    }

    cout << "Enter value: ";
    cin >> value;

    for(int i=n; i>pos; i--)
        arr[i] = arr[i-1];

    arr[pos] = value;
    n++;

    display(arr,n);
}

void deletion(int arr[], int &n)
{
    int pos;

    cout << "Enter index to delete: ";
    cin >> pos;

    if(pos < 0 || pos >= n)
    {
        cout << "Invalid position" << endl;
        return;
    }

    for(int i=pos; i<n-1; i++)
        arr[i] = arr[i+1];

    n--;

    cout << "Deleted successfully" << endl;
    display(arr,n);
}

void search(int arr[], int n)
{
    int key, found=0;

    cout << "Enter element to search: ";
    cin >> key;

    for(int i=0; i<n; i++)
    {
        if(arr[i] == key)
        {
            cout << "Element found at index " << i << endl;
            found=1;
            break;
        }
    }

    if(found == 0)
        cout << "Element not found" << endl;
}

void update(int arr[], int n)
{
    int pos, value;

    cout << "Enter index to update: ";
    cin >> pos;

    if(pos < 0 || pos >= n)
    {
        cout << "Invalid position" << endl;
        return;
    }

    cout << "Enter new value: ";
    cin >> value;

    arr[pos] = value;

    cout << "Updated successfully" << endl;
    display(arr,n);
}

int main()
{
    int arr[100], n, choice;

    cout << "Enter array size: ";
    cin >> n;

    if(n <= 0 || n > 100)
    {
        cout << "Invalid size";
        return 0;
    }

    cout << "Enter array elements: ";

    for(int i=0; i<n; i++)
        cin >> arr[i];

    do
    {
        cout << "\n1.Insert";
        cout << "\n2.Delete";
        cout << "\n3.Search";
        cout << "\n4.Update";
        cout << "\n5.Display";
        cout << "\n6.Exit";

        cout << "\nEnter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                insert(arr,n);
                break;

            case 2:
                deletion(arr,n);
                break;

            case 3:
                search(arr,n);
                break;

            case 4:
                update(arr,n);
                break;

            case 5:
                display(arr,n);
                break;

            case 6:
                cout << "Program terminated";
                break;

            default:
                cout << "Invalid choice";
        }

    }while(choice != 6);

    return 0;
}

