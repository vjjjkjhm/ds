#include<iostream>
using namespace std;
int fact(int num){
	if(num==0|| num==1){
		return 1;
	}
	return num*fact(num-1);
}
int main(){
	int n;
	cout<<"enter number to calculate factorial:"<<endl;
	cin>>n;

	if(n<0)
	{
		cout<<"factorial  is not defined for negative numbers"<<endl;
		return 0;
	}
	cout<<"factorial of \t"<<n<<"\t is :"<<fact(n);
	return 0;
}
