
#include<iostream>
using namespace std;

class queue{
    int *arr;
    int size;
    int front,rear;

public:

    queue(int size){
        this->size=size;
        arr=new int[size];
        front=-1;
        rear=-1;
    }

    void enqueue(){

        if(rear==size-1){
            cout<<"queue overflow..."<<endl;
            return;
        }

        int n;
        cout<<"enter number:"<<endl;
        cin>>n;

        if(front==-1){
            front=0;
        }

        rear++;
        arr[rear]=n;

        cout<<"element inserted..."<<endl;
    }

    void dequeue(){

        if(front==-1){
            cout<<"queue underflow"<<endl;
            return;
        }

        cout<<"deleted element:"<<arr[front]<<endl;

        if(front==rear){
            front=-1;
            rear=-1;
        }
        else{
            front++;
        }
    }

    void traversal(){

        if(front==-1){
            cout<<"queue is empty"<<endl;
            return;
        }

        cout<<"queue elements:"<<endl;

        for(int i=front;i<=rear;i++){
            cout<<arr[i]<<"\t";
        }

        cout<<endl;
    }

    ~queue(){
        delete[] arr;
    }
};

int main(){

    queue q(5);
    int choice;

    do{

        cout<<"\n1.enqueue"<<endl;
        cout<<"2.dequeue"<<endl;
        cout<<"3.traversal"<<endl;
        cout<<"4.exit"<<endl;

        cout<<"enter choice:"<<endl;
        cin>>choice;

        switch(choice){

            case 1:
                q.enqueue();
                break;

            case 2:
                q.dequeue();
                break;

            case 3:
                q.traversal();
                break;

            case 4:
                cout<<"program terminated"<<endl;
                break;

            default:
                cout<<"invalid choice"<<endl;
        }

    }while(choice!=4);

    return 0;
}

