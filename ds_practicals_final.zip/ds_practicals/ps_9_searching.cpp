#include<iostream>
using namespace std;

int id[50], n;
int entered = 0;

// Function to accept customer IDs
void accept()
{
    cout << "Enter number of customers: ";
    cin >> n;

    if(n <= 0 || n > 50)
    {
        cout << "Invalid number of customers!";
        n = 0;
        entered = 0;
        return;
    }

    for(int i = 0; i < n; i++)
    {
        cout << "Enter customer account ID: ";
        cin >> id[i];
    }

    entered = 1;
}

// Function for Linear Search
void linear_search(int key)
{
    int found = 0;
    int count = 0;

    for(int i = 0; i < n; i++)
    {
        count++;

        if(id[i] == key)
        {
            cout << "Customer ID found at position: " << i+1 << endl;
            found = 1;
            break;
        }
    }

    if(found == 0)
        cout << "Customer ID not found!" << endl;

    cout << "Number of comparisons: " << count << endl;
}

// Function to sort IDs using Bubble Sort
void sort_ids(int a[])
{
    for(int i = 0; i < n-1; i++)
    {
        for(int j = 0; j < n-i-1; j++)
        {
            if(a[j] > a[j+1])
            {
                int temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}

// Function for Binary Search
void binary_search(int key)
{
    int a[50];

    // Copy original IDs
    for(int i = 0; i < n; i++)
    {
        a[i] = id[i];
    }

    // Sort the copied array
    sort_ids(a);

    cout << "\nSorted Customer IDs: ";

    for(int i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }

    // Binary Search
    int low = 0;
    int high = n-1;
    int mid;
    int found = 0;
    int count = 0;

    while(low <= high)
    {
        mid = (low + high) / 2;
        count++;

        if(a[mid] == key)
        {
            cout << "\nCustomer ID found at sorted position: " << mid+1;
            found = 1;
            break;
        }
        else if(key > a[mid])
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    if(found == 0)
        cout << "\nCustomer ID not found!";

    cout << "\nNumber of search comparisons: " << count << endl;
}

// Main Function
int main()
{
    int ch, key;

    do
    {
        cout << "\n\n===== CUSTOMER DATABASE =====";
        cout << "\n1. Accept Customer IDs";
        cout << "\n2. Linear Search";
        cout << "\n3. Binary Search";
        cout << "\n4. Exit";

        cout << "\nEnter your choice: ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                accept();
                break;

            case 2:
                if(entered == 1)
                {
                    cout << "Enter ID to search: ";
                    cin >> key;

                    linear_search(key);
                }
                else
                {
                    cout << "Enter customer IDs first!";
                }
                break;

            case 3:
                if(entered == 1)
                {
                    cout << "Enter ID to search: ";
                    cin >> key;

                    binary_search(key);
                }
                else
                {
                    cout << "Enter customer IDs first!";
                }
                break;

            case 4:
                cout << "Program terminated.";
                break;

            default:
                cout << "Invalid choice!";
        }

    }while(ch != 4);

    return 0;
}
