#include<iostream>
using namespace std;

int roll[50], marks[50][10];
int n, s;
int total[50] = {0};
int entered = 0;

// 1. Accept student details
void accept()
{
    for(int i = 0; i < n; i++)
    {
        cout << "\nEnter roll number: ";
        cin >> roll[i];

        total[i] = 0;

        for(int j = 0; j < s; j++)
        {
            cout << "Enter marks of subject " << j+1 << ": ";
            cin >> marks[i][j];

            total[i] = total[i] + marks[i][j];
        }
    }

    entered = 1;
    cout << "\nDetails accepted successfully!";
}

// 2. Display student marks
void display()
{
    cout << "\nRoll\t";

    for(int j = 0; j < s; j++)
    {
        cout << "Sub" << j+1 << "\t";
    }

    cout << endl;

    for(int i = 0; i < n; i++)
    {
        cout << roll[i] << "\t";

        for(int j = 0; j < s; j++)
        {
            cout << marks[i][j] << "\t";
        }

        cout << endl;
    }
}

// 3. Calculate total marks
void total_marks()
{
    for(int i = 0; i < n; i++)
    {
        cout << "\nRoll No: " << roll[i];
        cout << " Total: " << total[i];
    }
}

// 4. Calculate subject average
void average()
{
    for(int j = 0; j < s; j++)
    {
        int sum = 0;

        for(int i = 0; i < n; i++)
        {
            sum = sum + marks[i][j];
        }

        cout << "\nSubject " << j+1;
        cout << " Average: " << (float)sum/n;
    }
}

// Main function
int main()
{
    int ch;

    cout << "Enter number of students: ";
    cin >> n;

    cout << "Enter number of subjects: ";
    cin >> s;

    if(n <= 0 || n > 50 || s <= 0 || s > 10)
    {
        cout << "Invalid input!";
        return 0;
    }

    do
    {
        cout << "\n\n===== STUDENT MARKS SYSTEM =====";
        cout << "\n1. Accept Details";
        cout << "\n2. Display Marks";
        cout << "\n3. Total Marks";
        cout << "\n4. Subject Average";
        cout << "\n5. Complete Result";
        cout << "\n6. Exit";

        cout << "\nEnter choice: ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                accept();
                break;

            case 2:
                if(entered == 1)
                    display();
                else
                    cout << "Enter details first!";
                break;

            case 3:
                if(entered == 1)
                    total_marks();
                else
                    cout << "Enter details first!";
                break;

            case 4:
                if(entered == 1)
                    average();
                else
                    cout << "Enter details first!";
                break;

            case 5:
                if(entered == 1)
                {
                    display();
                    total_marks();
                    average();
                }
                else
                    cout << "Enter details first!";
                break;

            case 6:
                cout << "Program terminated.";
                break;

            default:
                cout << "Invalid choice!";
        }

    }while(ch != 6);

    return 0;
}
