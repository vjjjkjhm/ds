#include<iostream>
#include<string>
using namespace std;
class student{
	private:
		int rollno;
		string name;
		float marks;
	public:
		void createdata(){
			cout<<"enter name:"<<endl;
			cin>>name;
			cout<<"enter roll no:"<<endl;
			cin>>rollno;
			cout<<"enter marks:"<<endl;
			cin>>marks;
		}
		void display(){
			cout<<"name:"<<name<<endl;
			cout<<"roll no:"<<rollno<<endl;
			cout<<"marks:"<<marks<<endl;
		}
		void compare(student &s2){
			if(marks > s2.marks){
				cout<<name<<"has greater marks than \n"<<s2.name<<endl;
			}
			else if(marks < s2.marks){
				cout<<s2.name<<"has graeter marks than \n"<<name<<endl;
			}
			else{
				cout<<"both having same marks\n"<<endl;
			}
		}
};
int main(){
	student s1,s2;
	cout<<"s1 data"<<endl;
	s1.createdata();
	s1.display();
	cout<<"s2 data"<<endl;
	s2.createdata();
	s2.display();
	cout<<"comparison on the basis of marks"<<endl;
	s1.compare(s2);
	return 0;
}
