
#include<iostream>
using namespace std;

void fibonacci(int n, int a, int b)
{
    if(n == 0)
        return;

    cout << a << " ";

    fibonacci(n-1, b, a+b);
}

int main()
{
    int n;

    cout << "Enter number of terms: ";
    cin >> n;

    if(n <= 0)
    {
        cout << "Invalid input";
        return 0;
    }

    cout << "Fibonacci series: ";

    fibonacci(n, 0, 1);

    return 0;
}

