
#include<iostream>
using namespace std;

class node
{
public:
    int data;
    node *next;

    node(int val)
    {
        data=val;
        next=NULL;
    }
};

class list
{
    node *head, *tail;

public:

    list()
    {
        head=tail=NULL;
    }

    void insert_at_start(int n)
    {
        node *newnode=new node(n);

        if(head==NULL)
            head=tail=newnode;
        else
        {
            newnode->next=head;
            head=newnode;
        }
    }

    void insert_at_end(int n)
    {
        node *newnode=new node(n);

        if(head==NULL)
            head=tail=newnode;
        else
        {
            tail->next=newnode;
            tail=newnode;
        }
    }

    void insert_at_any_pos(int n, int pos)
    {
        if(pos<=0)
        {
            cout << "Invalid position";
            return;
        }

        if(pos==1)
        {
            insert_at_start(n);
            return;
        }

        node *temp=head;

        for(int i=1; i<pos-1 && temp!=NULL; i++)
            temp=temp->next;

        if(temp==NULL)
        {
            cout << "Invalid position";
            return;
        }

        node *newnode=new node(n);

        newnode->next=temp->next;
        temp->next=newnode;

        if(newnode->next==NULL)
            tail=newnode;
    }

    void deletion(int pos)
    {
        if(head==NULL || pos<=0)
        {
            cout << "Invalid deletion";
            return;
        }

        node *temp=head;

        if(pos==1)
        {
            head=head->next;

            if(head==NULL)
                tail=NULL;
        }
        else
        {
            node *prev=NULL;

            for(int i=1; i<pos && temp!=NULL; i++)
            {
                prev=temp;
                temp=temp->next;
            }

            if(temp==NULL)
            {
                cout << "Invalid position";
                return;
            }

            prev->next=temp->next;

            if(temp==tail)
                tail=prev;
        }

        cout << "Deleted element: " << temp->data << endl;
        delete temp;
    }

    void searching(int key)
    {
        node *temp=head;
        int pos=1;

        while(temp!=NULL)
        {
            if(temp->data==key)
            {
                cout << "Element found at position: " << pos << endl;
                return;
            }

            temp=temp->next;
            pos++;
        }

        cout << "Element not found" << endl;
    }

    void display()
    {
        if(head==NULL)
        {
            cout << "List is empty";
            return;
        }

        node *temp=head;

        while(temp!=NULL)
        {
            cout << temp->data << " -> ";
            temp=temp->next;
        }

        cout << "NULL" << endl;
    }

    ~list()
    {
        node *temp;

        while(head!=NULL)
        {
            temp=head;
            head=head->next;
            delete temp;
        }

        tail=NULL;
    }
};

int main()
{
    list s;
    int choice, n, pos, key;

    do
    {
        cout << "\n1.Insert at start";
        cout << "\n2.Insert at end";
        cout << "\n3.Insert at position";
        cout << "\n4.Delete at position";
        cout << "\n5.Search";
        cout << "\n6.Display";
        cout << "\n7.Exit";

        cout << "\nEnter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter value: ";
                cin >> n;
                s.insert_at_start(n);
                break;

            case 2:
                cout << "Enter value: ";
                cin >> n;
                s.insert_at_end(n);
                break;

            case 3:
                cout << "Enter value and position: ";
                cin >> n >> pos;
                s.insert_at_any_pos(n,pos);
                break;

            case 4:
                cout << "Enter position: ";
                cin >> pos;
                s.deletion(pos);
                break;

            case 5:
                cout << "Enter element to search: ";
                cin >> key;
                s.searching(key);
                break;

            case 6:
                s.display();
                break;

            case 7:
                cout << "Program terminated";
                break;

            default:
                cout << "Invalid choice";
        }

    }while(choice!=7);

    return 0;
}

