#include<iostream>
using namespace std;
class stack{
	int *arr;
	int top;
	int size;
	public:
		stack(int size){
			this->size=size;
			arr=new int[size];
			top=-1;
		}
		void push(){
			int n;
			
			if(top==size-1){
				cout<<"stack overflow"<<endl;
				return;
			}
			cout<<"enter number to insert:"<<endl;
			cin>>n;
			top++;
			arr[top]=n;
			cout<<"element inserted successfully"<<endl;
		}
		void pop(){
			if(top==-1){
				cout<<"stack underflow"<<endl;
				return;
			}
			cout<<"deleted element:"<<arr[top];
			top--;
		}
		int peek(){
			if(top==-1){
				cout<<"stack underflow"<<endl;
			    return -1;
			}
			return arr[top];
		}
		void display(){
			cout<<"stack elemets:"<<endl;
			for(int i=top;i>=0;i--){
				cout<<arr[i]<<" ";
			}
			cout<<endl;
		}
		~stack(){
			delete[]  arr;
		}
};
int main(){
	stack s(5);
	int choice;
	do{
		
		cout<<"1.push"<<endl;
		cout<<"2.pop"<<endl;
		cout<<"3.peek"<<endl;
		cout<<"4.display"<<endl;
		cout<<"5.exit"<<endl;
		cout<<"enter choice:"<<endl;
		cin>>choice;
		switch(choice){
			
			case 1:
				s.push();
				break;
			case 2:
				s.pop();
				break;
			case 3:
				cout<<"top element:"<<s.peek()<<endl;
				break;
			case 4:
				s.display();
				break;
			case 5:
				cout<<"program terminated"<<endl;
				break;
			default:
				cout<<"invalid choice";
		}
	}while(choice!=5);
	
	return 0;
}
